<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839c3b25bf             |
    |_______________________________________|
*/
 use Pmpr\Module\FAQ\FAQ; FAQ::symcgieuakksimmu();
