<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598d031a86             |
    |_______________________________________|
*/
 use Pmpr\Module\FAQ\FAQ; FAQ::symcgieuakksimmu();
