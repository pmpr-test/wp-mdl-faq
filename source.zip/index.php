<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e015889d8             |
    |_______________________________________|
*/
 use Pmpr\Module\FAQ\FAQ; FAQ::symcgieuakksimmu();
