<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ec1a67d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x46\x41\x51\x20\x53\x65\x74\164\151\x6e\147", PR__MDL__FAQ); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\123\145\164\164\x69\x6e\x67", PR__MDL__FAQ)); } }
