<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e585ee6399d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Module\StructuredData\AbstractStructuredData; class StructuredData extends AbstractStructuredData { }
