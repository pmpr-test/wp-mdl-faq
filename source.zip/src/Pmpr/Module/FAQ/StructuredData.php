<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68d2c860a9d38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Module\StructuredData\AbstractStructuredData; class StructuredData extends AbstractStructuredData { }
