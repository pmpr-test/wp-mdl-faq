<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7216e68a6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Module\StructuredData\AbstractStructuredData; class StructuredData extends AbstractStructuredData { }
