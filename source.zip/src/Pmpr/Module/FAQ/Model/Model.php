<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec71ab582             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Module\FAQ\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Question::symcgieuakksimmu(); } }
