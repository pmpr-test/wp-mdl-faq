<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ec1a67d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Category extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::uaimoioocayauuca)->wiskakymeaywyeuw($this->akuociswqmoigkas())->guiaswksukmgageq(__("\x43\x61\x74\145\x67\157\162\171", PR__MDL__FAQ))->muuwuqssqkaieqge(__("\103\x61\164\x65\147\157\162\x69\145\x73", PR__MDL__FAQ))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->gysoeyaguiyewoes(Constants::NAME)->gswweykyogmsyawy(__("\x4e\141\x6d\x65", PR__MDL__FAQ)), $this->qoemykoeuecmsmwe(Constants::iuqumwggccmcuyem)->gswweykyogmsyawy(__("\x50\x72\151\x6f\x72\x69\x74\x79", PR__MDL__FAQ))->eyygsasuqmommkua(0), $this->eoaomaokwkwqyqiq(self::qaouquqcwsmaaoow)->gswweykyogmsyawy(__("\103\x61\164\145\x67\157\162\171", PR__MDL__FAQ))->ckgquisaimmgwuyu()]); parent::ewaqwooqoqmcoomi(); } }
