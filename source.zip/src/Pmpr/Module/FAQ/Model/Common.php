<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e79b71424             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { const qweekaqwsewcacci = "\x71\x75\x65\163\164\x69\157\156\137\x69\x64"; const qaouquqcwsmaaoow = "\x63\x61\x74\x65\147\157\162\x79\x5f\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($this->akuociswqmoigkas()); } }
